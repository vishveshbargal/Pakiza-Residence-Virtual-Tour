var APP_DATA = {
  "scenes": [
    {
      "id": "0-site-plan",
      "name": "Site Plan",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -0.000658254741331632,
        "pitch": 1.5707963267948966,
        "fov": 1.2476858939469109
      },
      "linkHotspots": [
        {
          "yaw": -1.3449894551699906,
          "pitch": 1.1645146657263084,
          "rotation": 0,
          "target": "1-test_1---panorama"
        },
        {
          "yaw": -0.9098016784444418,
          "pitch": 1.0595393253909222,
          "rotation": 0,
          "target": "3-test_3---panorama"
        },
        {
          "yaw": -1.1237406305603734,
          "pitch": 1.1114534322295135,
          "rotation": 0,
          "target": "2-test_9---panorama"
        },
        {
          "yaw": -0.043944623135212524,
          "pitch": 1.5278096988663297,
          "rotation": 0,
          "target": "4-test_2---panorama"
        },
        {
          "yaw": -0.12287621759165113,
          "pitch": 1.3538143785768515,
          "rotation": 0,
          "target": "5-test_4---panorama"
        },
        {
          "yaw": 1.1821645823263864,
          "pitch": 0.9402873016430249,
          "rotation": 0,
          "target": "6-test_6---panorama"
        },
        {
          "yaw": 1.4126283755396631,
          "pitch": 1.3113740133110863,
          "rotation": 0,
          "target": "7-test_7---panorama"
        },
        {
          "yaw": -1.035930862378187,
          "pitch": 0.9504149253461911,
          "rotation": 0,
          "target": "8-test_8---panorama"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-test_1---panorama",
      "name": "test_1 - Panorama",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    },
    {
      "id": "2-test_9---panorama",
      "name": "test_9 - Panorama",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    },
    {
      "id": "3-test_3---panorama",
      "name": "test_3 - Panorama",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    },
    {
      "id": "4-test_2---panorama",
      "name": "test_2 - Panorama",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    },
    {
      "id": "5-test_4---panorama",
      "name": "test_4 - Panorama",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    },
    {
      "id": "6-test_6---panorama",
      "name": "test_6 - Panorama",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    },
    {
      "id": "7-test_7---panorama",
      "name": "test_7 - Panorama",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    },
    {
      "id": "8-test_8---panorama",
      "name": "test_8 - Panorama",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
